

'''
Copyright (C) 2016 Cedric lepiller
pitiwazou@gmail.com

Created by Cedric lepiller

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

bl_info = {
    "name": "SpeedRetopo",
    "description": "Addon for retopology",
    "author": "Cedric Lepiller, EWOC for Laprelax, Lapineige for Automirror",
    "version": (0, 1, 0),
    "blender": (2, 79, 0),
    "location": "View3D",
    "warning": "This addon is still in development.",
    "wiki_url": "",
    "category": "Object" }
    


import bpy
import bmesh
from mathutils import *
import math
from bpy.types import AddonPreferences, PropertyGroup
from bpy.types import Menu, Header  
from bpy.props import (StringProperty, 
                       BoolProperty, 
                       FloatVectorProperty,
                       FloatProperty,
                       EnumProperty,
                       IntProperty)
from bpy.types import Operator, Macro
import os
import rna_keymap_ui



    
    
# -----------------------------------------------------------------------------
#    Funtions
# ----------------------------------------------------------------------------- 
bpy.types.WindowManager.ref_obj = bpy.props.StringProperty()
bpy.types.Scene.previews_obj = bpy.props.StringProperty()
bpy.types.Scene.obj_mode = bpy.props.StringProperty()

# -----------------------------------------------------------------------------
#    Activate addons
# ----------------------------------------------------------------------------- 

class ActivateBsurfaces(bpy.types.Operator):
    bl_idname = "object.activate_bsurfaces"
    bl_label = "Activate Bsurfaces"
    bl_description = "Activate Bsurfaces"
    bl_options = {"REGISTER"}


    def execute(self, context):
        bpy.ops.wm.addon_enable(module="mesh_bsurfaces")
        bpy.ops.wm.save_userpref()
        return {"FINISHED"}

class ActivateLooptools(bpy.types.Operator):
    bl_idname = "object.activate_looptools"
    bl_label = "Activate Lopptools"
    bl_description = "Activate Looptools"
    bl_options = {"REGISTER"}


    def execute(self, context):
        bpy.ops.wm.addon_enable(module="mesh_looptools")
        bpy.ops.wm.save_userpref()
        return {"FINISHED"}

# -----------------------------------------------------------------------------
#    Scale Grid
# -----------------------------------------------------------------------------  

 
class Scale_Grid(bpy.types.Operator):
    bl_idname = "object.scale_grid"
    bl_label = "Scale Grid"
    bl_description = "Scale Grid"
    bl_options = {"REGISTER", "UNDO"}
 
    @classmethod
    def poll(cls, context):
        # autant s'assurer qu'on a bien un objet et que l'objet Retopo_Grid
        # fait bien partie de la scène pour pouvoir lancer l'opérateur
        return context.object is not None and "Retopo_Grid" in bpy.context.scene.objects
 
    def execute(self, context):
        obj = context.active_object
 
        # on sauvegarde le mode objet
        bpy.context.scene.obj_mode = bpy.context.object.mode
        # on sauvegarde le nom du mesh actif pour qu'on puisse le récupérer le moment venu
        bpy.context.scene.previews_obj = obj.name
 
        bpy.ops.object.mode_set(mode = 'OBJECT')
 
        # si il y a des chances qu'on ait plusieurs objets sélectionnés
        bpy.ops.object.select_all(action = 'DESELECT')
 
        # si au contraire on est certain qu'on aura qu'un seul de selectionné,
        # autant utiliser cette ligne
 
#        obj.select = False
        bpy.data.objects["Retopo_Grid"].hide_select = False
        bpy.context.scene.objects.active = bpy.data.objects["Retopo_Grid"]
        bpy.data.objects['Retopo_Grid'].select = True
        bpy.context.scene.tool_settings.use_snap = False
        
        


        # on lance la macro à partir d'ici
        bpy.ops.test.test_macro('INVOKE_DEFAULT')
        # c'est la macro qui doit lancer l'opérateur TRANSFORM_OT_resize pour qu'elle 
        # puisse détecter la fin de l'invoke et lancer la suite du code
        # une fois ce dernier terminé
        return {"FINISHED"}
 
class Finalize(Operator):
    bl_idname = "test.finalize"
    bl_label = "Finalize"
 
    def execute(self, context):
        bpy.context.scene.tool_settings.use_snap = True
        
        bpy.data.objects["Retopo_Grid"].hide_select = True

        # on désélectionne Retopo_Grid
        bpy.context.active_object.select = False
 
        # on récupère l'ancien objet grace à la variable dans laquelle on a stocké le nom
        previewsObj = bpy.data.objects[context.scene.previews_obj]
 
        bpy.context.scene.objects.active = previewsObj
        previewsObj.select = True
 
        if context.scene.obj_mode != bpy.context.object.mode:
            bpy.ops.object.mode_set(mode = bpy.context.scene.obj_mode)
 
        # on clean les variables
        bpy.context.scene.obj_mode = ""
        bpy.context.scene.previews_obj = ""
        return {'FINISHED'}
 
 
# Macro operator to concatenate transform and our finalization
class Test(Macro):
    bl_idname = "test.test_macro"
    bl_label = "Test"
    
# -----------------------------------------------------------------------------
#    Grid
# -----------------------------------------------------------------------------      

#Remove Grid  
class Remove_Retopo_Grid(bpy.types.Operator):
    bl_idname = "object.remove_retopo_grid"
    bl_label = "Remove Retopo Grid"
    bl_description = "Remove Retopo Grid"
    bl_options = {"REGISTER", "UNDO"}
    
    @classmethod
    def poll(cls, context):
        # autant s'assurer qu'on a bien un objet 
        return context.object is not None

    def execute(self, context):
        obj = context.active_object
        
        # on sauvegarde le mode objet
        bpy.context.scene.obj_mode = bpy.context.object.mode
        # on sauvegarde le nom du mesh actif pour qu'on puisse le récupérer le moment venu
        bpy.context.scene.previews_obj = obj.name
            
        ActObj_edit = False
        if bpy.context.object.mode == "EDIT":
            ActObj_edit = True
            bpy.ops.object.mode_set(mode = 'OBJECT')
        
        bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Shrinkwrap_Grid") 
        bpy.ops.object.select_all(action='DESELECT')
        bpy.data.objects["Retopo_Grid"].hide = False
        bpy.data.objects["Retopo_Grid"].hide_select = False
        bpy.context.scene.objects.active = bpy.data.objects["Retopo_Grid"]
        bpy.data.objects['Retopo_Grid'].select = True
        bpy.ops.object.delete(use_global=False)
        
        
        # on récupère l'ancien objet grace à la variable dans laquelle on a stocké le nom
        previewsObj = bpy.data.objects[context.scene.previews_obj]
 
        bpy.context.scene.objects.active = previewsObj
        previewsObj.select = True
 
        if context.scene.obj_mode != bpy.context.object.mode:
            bpy.ops.object.mode_set(mode = bpy.context.scene.obj_mode)
 
        # on clean les variables
        bpy.context.scene.obj_mode = ""
        bpy.context.scene.previews_obj = ""
        
        return {"FINISHED"}


#Create Grid    
class ReCreate_Grid(bpy.types.Operator):
    bl_idname = "object.recreate_grid"
    bl_label = "ReCreate Retopo Grid"
    bl_description = "ReCreate Retopo Grid"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        # autant s'assurer qu'on a bien un objet 
        return context.object is not None

    def execute(self, context):
        obj = context.active_object
        
        #Addon prefs
        addonPref = bpy.context.user_preferences.addons[__name__].preferences
        grid_color = addonPref.grid_color
        grid_subdivisions= addonPref.grid_subdivisions
        grid_show_wire= addonPref.grid_show_wire
        grid_alpha= addonPref.grid_alpha
        
        # on sauvegarde le mode objet
        bpy.context.scene.obj_mode = bpy.context.object.mode
        # on sauvegarde le nom du mesh actif pour qu'on puisse le récupérer le moment venu
        bpy.context.scene.previews_obj = obj.name
                    
        ActObj_edit = False
        if bpy.context.object.mode == "EDIT":
            ActObj_edit = True
    
    
        bpy.ops.object.mode_set(mode = 'OBJECT')  
        
        if not "Retopo_Grid" in bpy.data.objects :
            #Create Plane
            bpy.ops.mesh.primitive_plane_add(radius=1, view_align=False, enter_editmode=True)
            
            #Add Subsurf
            bpy.ops.object.modifier_add(type='SUBSURF')
            bpy.context.object.modifiers["Subsurf"].subdivision_type = 'SIMPLE'
            bpy.context.object.modifiers["Subsurf"].levels = grid_subdivisions
            if(hasattr(bpy.context.user_preferences.system, 'opensubdiv_compute_type')):
                bpy.context.object.modifiers["Subsurf"].use_opensubdiv = True

            bpy.ops.object.mode_set(mode = 'OBJECT')  
            bpy.context.active_object.name= "Retopo_Grid"
            
            #Edit values
            bpy.ops.transform.rotate(value=1.5708, axis=(0, 1, 0))
            bpy.ops.transform.resize(value=(100, 100, 100))
            bpy.context.object.data.show_double_sided = True
            bpy.context.object.show_transparent = True
            if grid_show_wire :
                bpy.context.object.show_wire = True
                bpy.context.object.show_all_edges = True

            #Add Material
            bpy.ops.object.material_slot_add()
            if not "Retopo_Grid" in bpy.data.materials:
                myMat = bpy.data.materials.new("Retopo_Grid")
                myMat.use_nodes = True
                bpy.context.object.active_material = myMat
            else:
                bpy.context.object.active_material = bpy.data.materials['Retopo_Grid']
            bpy.context.object.active_material.alpha = grid_alpha
            bpy.context.object.active_material.diffuse_color = grid_color
            bpy.context.object.active_material.specular_color = (0, 0, 0)    
            bpy.ops.object.select_all(action='DESELECT')
                
            
            # on récupère l'ancien objet grace à la variable dans laquelle on a stocké le nom
            previewsObj = bpy.data.objects[context.scene.previews_obj]
     
            bpy.context.scene.objects.active = previewsObj
            previewsObj.select = True
            

            if "Shrinkwrap_Grid" in obj.modifiers:
                bpy.context.object.modifiers["Shrinkwrap_Grid"].target = bpy.data.objects["Retopo_Grid"]
                
            #If no modifier, create it  
            else:       
                #Add Shrinkwrap Grid
                if "Shrinkwrap" in obj.modifiers:
                    bpy.ops.object.modifier_add(type='SHRINKWRAP')
                    bpy.context.object.modifiers["Shrinkwrap.001"].name = "Shrinkwrap_Grid"
                else:
                    bpy.ops.object.modifier_add(type='SHRINKWRAP')
                    bpy.context.object.modifiers["Shrinkwrap"].name = "Shrinkwrap_Grid"    
                bpy.context.object.modifiers["Shrinkwrap_Grid"].target = bpy.data.objects["Retopo_Grid"]
                bpy.context.object.modifiers["Shrinkwrap_Grid"].wrap_method = 'PROJECT'
                bpy.context.object.modifiers["Shrinkwrap_Grid"].use_project_x = True
                bpy.context.object.modifiers["Shrinkwrap_Grid"].show_on_cage = True
                bpy.context.object.modifiers["Shrinkwrap_Grid"].use_keep_above_surface = True
                bpy.ops.object.modifier_move_up(modifier="Shrinkwrap_Grid")
            
            bpy.data.objects["Retopo_Grid"].hide_select = True
            
            if context.scene.obj_mode != bpy.context.object.mode:
                bpy.ops.object.mode_set(mode = bpy.context.scene.obj_mode)
     
            # on clean les variables
            bpy.context.scene.obj_mode = ""
            bpy.context.scene.previews_obj = ""
            
        return {"FINISHED"} 


#Create Grid    
class Create_Grid(bpy.types.Operator):
    bl_idname = "object.create_grid"
    bl_label = "Create Retopo Grid"
    bl_description = "Create Retopo Grid"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        # autant s'assurer qu'on a bien un objet 
        return context.object is not None

    def execute(self, context):
        obj = context.active_object
        
        #Addon prefs
        addonPref = bpy.context.user_preferences.addons[__name__].preferences
        grid_color = addonPref.grid_color
        grid_subdivisions= addonPref.grid_subdivisions
        grid_show_wire= addonPref.grid_show_wire
        grid_alpha= addonPref.grid_alpha
        
        # on sauvegarde le mode objet
        bpy.context.scene.obj_mode = bpy.context.object.mode
        # on sauvegarde le nom du mesh actif pour qu'on puisse le récupérer le moment venu
        bpy.context.scene.previews_obj = obj.name

                
        ActObj_edit = False
        if bpy.context.object.mode == "EDIT":
            ActObj_edit = True
    
    
        bpy.ops.object.mode_set(mode = 'OBJECT')  
        
        #Create Grid
        if not "Retopo_Grid" in bpy.data.objects:
            #Create Plane
            bpy.ops.mesh.primitive_plane_add(radius=1, view_align=False, enter_editmode=True)
            
            #Add Subsurf
            bpy.ops.object.modifier_add(type='SUBSURF')
            bpy.context.object.modifiers["Subsurf"].subdivision_type = 'SIMPLE'
            bpy.context.object.modifiers["Subsurf"].levels = grid_subdivisions
            if(hasattr(bpy.context.user_preferences.system, 'opensubdiv_compute_type')):
                bpy.context.object.modifiers["Subsurf"].use_opensubdiv = True

            bpy.ops.object.mode_set(mode = 'OBJECT')  
            bpy.context.active_object.name= "Retopo_Grid"
            
            #Edit values
            bpy.ops.transform.rotate(value=1.5708, axis=(0, 1, 0))
            bpy.ops.transform.resize(value=(100, 100, 100))
            bpy.context.object.data.show_double_sided = True
            bpy.context.object.show_transparent = True
            if grid_show_wire :
                bpy.context.object.show_wire = True
                bpy.context.object.show_all_edges = True

            #Add Material
            bpy.ops.object.material_slot_add()
            if not "Retopo_Grid" in bpy.data.materials:
                myMat = bpy.data.materials.new("Retopo_Grid")
                myMat.use_nodes = True
                bpy.context.object.active_material = myMat
            else:
                bpy.context.object.active_material = bpy.data.materials['Retopo_Grid']
            bpy.context.object.active_material.alpha = grid_alpha
            bpy.context.object.active_material.diffuse_color = grid_color
            bpy.context.object.active_material.specular_color = (0, 0, 0)    
            bpy.ops.object.select_all(action='DESELECT')
            
            # on récupère l'ancien objet grace à la variable dans laquelle on a stocké le nom
            previewsObj = bpy.data.objects[context.scene.previews_obj]
     
            bpy.context.scene.objects.active = previewsObj
            previewsObj.select = True    
            
            bpy.data.objects["Retopo_Grid"].hide_select = True
            
            if context.scene.obj_mode != bpy.context.object.mode:
                bpy.ops.object.mode_set(mode = bpy.context.scene.obj_mode)
     
            # on clean les variables
            bpy.context.scene.obj_mode = ""
            bpy.context.scene.previews_obj = ""
            
        return {"FINISHED"}   
    
class Hide_Retopo_Grid(bpy.types.Operator):
    bl_idname = "object.hide_retopo_grid"
    bl_label = "Hide Retopo Grid"
    bl_description = "Hide Retopo Grid"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        obj = context.active_object
        
        if bpy.data.objects["Retopo_Grid"].hide == False :
            bpy.data.objects["Retopo_Grid"].hide = True
            if "Shrinkwrap_Grid" in obj.modifiers :   
                bpy.context.object.modifiers["Shrinkwrap_Grid"].show_viewport = False
        
        elif bpy.data.objects["Retopo_Grid"].hide == True :
            bpy.data.objects["Retopo_Grid"].hide = False
            if "Shrinkwrap_Grid" in obj.modifiers :  
                bpy.context.object.modifiers["Shrinkwrap_Grid"].show_viewport = True

        return {"FINISHED"}
               
# -----------------------------------------------------------------------------
#    Setup Retopo
# ----------------------------------------------------------------------------- 

# Setup Retopo
class CreateSpeedRetopo(bpy.types.Operator):
    bl_idname = "object.create_speed_retopo"
    bl_label = "Create Speed Retopo"
    bl_description = "Create Speed Retopo"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        addonPref = bpy.context.user_preferences.addons[__name__].preferences
        use_grid = addonPref.use_grid
        
        context.window_manager.ref_obj = context.active_object.name 
        ref_obj = bpy.context.window_manager.ref_obj 
        
        obj = context.active_object
                   
        #Prepare Grease Pencil
        bpy.context.scene.tool_settings.grease_pencil_source = 'OBJECT'
        bpy.context.scene.tool_settings.gpencil_stroke_placement_view3d = 'SURFACE'
        
        #Add snap
        bpy.context.scene.tool_settings.use_snap = True
        bpy.context.scene.tool_settings.snap_element = 'FACE'
        
        
        
        #Create Empty mesh
        bpy.ops.mesh.primitive_plane_add(radius=1, view_align=False, enter_editmode=False)
        bpy.context.active_object.name= "Retopo_Mesh"
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.delete(type='VERT')    
        bpy.ops.object.mode_set(mode = 'OBJECT')  
        
        #Add Grid
        if use_grid:
            bpy.ops.object.create_grid()
        
        #Prepare shading
        bpy.context.object.show_x_ray = True
        bpy.context.space_data.show_occlude_wire = True
        
        #Add Mirror
        bpy.ops.object.modifier_add(type='MIRROR')
        bpy.context.object.modifiers["Mirror"].use_x = True
        bpy.context.object.modifiers["Mirror"].use_clip = True
        bpy.context.object.modifiers["Mirror"].use_mirror_merge = True
        bpy.context.object.modifiers["Mirror"].show_on_cage = True
        bpy.context.object.modifiers["Mirror"].merge_threshold = 0.05

        #Add Shrinkwrap
        bpy.ops.object.modifier_add(type='SHRINKWRAP')
        bpy.context.object.modifiers["Shrinkwrap"].target = bpy.data.objects[ref_obj]
        bpy.context.object.modifiers["Shrinkwrap"].show_on_cage = True
        bpy.context.object.modifiers["Shrinkwrap"].use_keep_above_surface = True
        bpy.ops.object.modifier_move_up(modifier="Shrinkwrap")
        
        
        
        #Add Shrinkwrap Grid
        if use_grid:
            bpy.ops.object.modifier_add(type='SHRINKWRAP')  
            bpy.context.object.modifiers["Shrinkwrap.001"].name = "Shrinkwrap_Grid"
            bpy.context.object.modifiers["Shrinkwrap_Grid"].target = bpy.data.objects["Retopo_Grid"]
            
            bpy.context.object.modifiers["Shrinkwrap_Grid"].wrap_method = 'PROJECT'
            bpy.context.object.modifiers["Shrinkwrap_Grid"].use_project_x = True

            bpy.context.object.modifiers["Shrinkwrap_Grid"].show_on_cage = True
            bpy.context.object.modifiers["Shrinkwrap_Grid"].use_keep_above_surface = True
            bpy.ops.object.modifier_move_up(modifier="Shrinkwrap_Grid")
        
        bpy.ops.object.mode_set(mode = 'EDIT')
        return {"FINISHED"}

# -----------------------------------------------------------------------------
#    Align to X
# ----------------------------------------------------------------------------- 

#Align to X
class AlignToX(bpy.types.Operator):  
    bl_idname = "object.align2x"  
    bl_label = "Align To X"
    bl_description = "Align To X"   
    bl_options = {'REGISTER', 'UNDO'}
  
    def execute(self, context):
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

        for vert in bpy.context.object.data.vertices:
            if vert.select: 
                vert.co[0] = 0
        bpy.ops.object.editmode_toggle() 
        return {'FINISHED'} 


# -----------------------------------------------------------------------------
#    Mirror
# -----------------------------------------------------------------------------  
    
#Apply Mirror
class ApplyMirror(bpy.types.Operator):  
    bl_idname = "apply.mirror"  
    bl_label = "Apply Mirror" 
    bl_description = "Apply Mirror" 
    bl_options = {'REGISTER', 'UNDO'}
  
    def execute(self, context):
        if "Retopo_Grid" in bpy.data.objects:
            bpy.ops.object.remove_retopo_grid()
        
        if bpy.context.object.mode == "OBJECT":
            bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Mirror")

            
        elif bpy.context.object.mode == "EDIT":
            bpy.ops.object.mode_set(mode = 'OBJECT')
            bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Mirror")
            bpy.ops.object.mode_set(mode = 'EDIT')
        
        
        return {'FINISHED'} 

#Remove
class RemoveMirror(bpy.types.Operator):
    bl_idname = "object.remove_mirror"
    bl_label = "Remove Mirror"
    bl_description = "Remove Mirror"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        bpy.ops.object.modifier_remove(modifier="Mirror")
        return {"FINISHED"}
            
 
    
# -----------------------------------------------------------------------------
#    Shrinkwrap
# -----------------------------------------------------------------------------  

#Apply Shrinkwrap
class ApplyShrinkwrap(bpy.types.Operator):  
    bl_idname = "apply.shrinkwrap"  
    bl_label = "Apply Shrinkwrap Modifier"  
    bl_description = "Apply Shrinkwrap Modifier"
    bl_options = {'REGISTER', 'UNDO'}
  
    def execute(self, context):
        if bpy.context.object.mode == "OBJECT":
            bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Shrinkwrap")

        elif bpy.context.object.mode == "EDIT":
            bpy.ops.object.mode_set(mode = 'OBJECT')
            bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Shrinkwrap")
            bpy.ops.object.mode_set(mode = 'EDIT')
        
        return {'FINISHED'} 

#Add Shrinkwrap
class AddShrinkwrap(bpy.types.Operator):
    bl_idname = "object.add_shrinkwrap"
    bl_label = "Add Shrinkwrap"
    bl_description = "Add Shrinkwrap Modifier"
    bl_options = {"REGISTER", 'UNDO'}

    def execute(self, context):
        ref_obj = bpy.context.window_manager.ref_obj 
    
        bpy.ops.object.modifier_add(type='SHRINKWRAP')
        bpy.context.object.modifiers["Shrinkwrap"].target = bpy.data.objects[ref_obj]
        bpy.context.object.modifiers["Shrinkwrap"].show_on_cage = True
        bpy.context.object.modifiers["Shrinkwrap"].use_keep_above_surface = True
        bpy.ops.object.modifier_move_up(modifier="Shrinkwrap")
        bpy.ops.object.modifier_move_up(modifier="Shrinkwrap")
        bpy.ops.object.modifier_move_up(modifier="Shrinkwrap")
        return {"FINISHED"}
    
#Update Shrinkwrap
class Update_Shrinwrap(bpy.types.Operator):
    bl_idname = "object.update_shrinwrap"
    bl_label = "Update Shrinwrap"
    bl_description = "Update Shrinwrap"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        bpy.ops.apply.shrinkwrap()
        bpy.ops.object.add_shrinkwrap()
        return {"FINISHED"}
   
# -----------------------------------------------------------------------------
#    LapRelax
# -----------------------------------------------------------------------------  
      
#LapRelax
class SRRelax(bpy.types.Operator):
    bl_idname = "mesh.speed_retopo_relax"
    bl_label = "Relax"
    bl_description = "Smoothing mesh keeping volume"
    bl_options = {'REGISTER', 'UNDO'}
    
    Repeat = bpy.props.IntProperty(
        name = "Repeat", 
        description = "Repeat how many times",
        default = 5,
        min = 1,
        max = 100)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj and obj.type == 'MESH' and context.mode == 'EDIT_MESH')

    def invoke(self, context, event):
        
        # smooth #Repeat times
        for i in range(self.Repeat):
            self.do_laprelax()
        
        bpy.ops.mesh.select_all(action='DESELECT') 
        return {'FINISHED'}


    def do_laprelax(self):
    
        context = bpy.context
        region = context.region  
        area = context.area
        selobj = bpy.context.active_object
        mesh = selobj.data
        bm = bmesh.from_edit_mesh(mesh)
        bmprev = bm.copy()
        vertices = [v for v in bmprev.verts if v.select]
        
        if not vertices:
            bpy.ops.mesh.select_all(action='SELECT')
        
        for v in bmprev.verts:
            
            if v.select:
                
                tot = Vector((0, 0, 0))
                cnt = 0
                for e in v.link_edges:
                    for f in e.link_faces:
                        if not(f.select):
                            cnt = 1
                    if len(e.link_faces) == 1:
                        cnt = 1
                        break
                if cnt:
                    # dont affect border edges: they cause shrinkage
                    continue
                    
                # find Laplacian mean
                for e in v.link_edges:
                    tot += e.other_vert(v).co
                tot /= len(v.link_edges)
                
                # cancel movement in direction of vertex normal
                delta = (tot - v.co)
                if delta.length != 0:
                    ang = delta.angle(v.normal)
                    deltanor = math.cos(ang) * delta.length
                    nor = v.normal
                    nor.length = abs(deltanor)
                    bm.verts.ensure_lookup_table()
                    bm.verts[v.index].co = tot + nor
            
            
        mesh.update()
        bm.free()
        bmprev.free()
        bpy.ops.object.editmode_toggle()
        bpy.ops.object.editmode_toggle()

#Space Relax        
class SpaceRelax(bpy.types.Operator):
    bl_idname = "object.space_relax"
    bl_label = "Space Relax"
    bl_description = ""
    bl_options = {"REGISTER"}

    def execute(self, context):
        bpy.ops.mesh.looptools_space()
        bpy.ops.mesh.looptools_relax()
        
        return {"FINISHED"}
                

        
# -----------------------------------------------------------------------------
#    Auto Mirror
# -----------------------------------------------------------------------------  
bpy.types.Scene.AutoMirror_cut = bpy.props.BoolProperty(default= True, description="If enabeled, cut the mesh in two parts and mirror it. If not, just make a loopcut")
#Auto Mirror
class MeshAlignVertices(bpy.types.Operator):
    """  """
    bl_idname = "object.mesh_align_vertices"
    bl_label = "Align Vertices on 1 Axis"

    def execute(self, context):
        bpy.ops.object.mode_set(mode = 'OBJECT')

        x1,y1,z1 = bpy.context.scene.cursor_location
        bpy.ops.view3d.snap_cursor_to_selected()

        x2,y2,z2 = bpy.context.scene.cursor_location

        bpy.context.scene.cursor_location[0],bpy.context.scene.cursor_location[1],bpy.context.scene.cursor_location[2]  = 0,0,0

        #Vertices coordinate to 0 (local coordinate, so on the origin)
        for vert in bpy.context.object.data.vertices:
            if vert.select:
                axis = 0
                vert.co[axis] = 0

        bpy.context.scene.cursor_location = x2,y2,z2

        bpy.ops.object.origin_set(type='ORIGIN_CURSOR')

        bpy.context.scene.cursor_location = x1,y1,z1

        bpy.ops.object.mode_set(mode = 'EDIT')  
        return {'FINISHED'}

class MeshAutoMirror(bpy.types.Operator):
    """ Automatically cut an object along an axis """
    bl_idname = "object.mesh_automirror"
    bl_label = "AutoMirror"
    bl_options = {'REGISTER', 'UNDO'}

    
    def get_local_axis_vector(self, context, X, Y, Z, orientation):
        loc = context.object.location
        bpy.ops.object.mode_set(mode="OBJECT") # Needed to avoid to translate vertices
        
        v1 = Vector((loc[0],loc[1],loc[2]))
        bpy.ops.transform.translate(value=(X*orientation, Y*orientation, Z*orientation), constraint_axis=((X==1), (Y==1), (Z==1)), constraint_orientation='LOCAL')
        v2 = Vector((loc[0],loc[1],loc[2]))
        bpy.ops.transform.translate(value=(-X*orientation, -Y*orientation, -Z*orientation), constraint_axis=((X==1), (Y==1), (Z==1)), constraint_orientation='LOCAL')
        
        bpy.ops.object.mode_set(mode="EDIT")
        return v2-v1
    
    def execute(self, context):
        X,Y,Z = 0,0,0
        X = 1
        
        current_mode = bpy.context.object.mode # Save the current mode
        
        if bpy.context.object.mode != "EDIT":
            bpy.ops.object.mode_set(mode="EDIT") # Go to edit mode
        bpy.ops.mesh.select_all(action='SELECT') # Select all the vertices
        
        #Direction of the mirror
        orientation = 1
        cut_normal = self.get_local_axis_vector(context, X, Y, Z, orientation)
            
        bpy.ops.mesh.bisect(plane_co=(bpy.context.object.location[0], bpy.context.object.location[1], bpy.context.object.location[2]), plane_no=cut_normal, use_fill= False, clear_inner= bpy.context.scene.AutoMirror_cut, clear_outer= 0, threshold= 0.01) # Cut the mesh
        
        bpy.ops.object.mesh_align_vertices() # Use to align the vertices on the origin, needed by the "threshold"
        
        bpy.ops.object.mode_set(mode=current_mode) # Reload previous mode
        
        #Add mirror
        bpy.ops.object.modifier_add(type='MIRROR') # Add a mirror modifier
        bpy.context.object.modifiers["Mirror"].use_clip = True
        bpy.context.object.modifiers["Mirror"].use_mirror_merge = True
        bpy.context.object.modifiers["Mirror"].show_on_cage = True
        bpy.context.object.modifiers["Mirror"].merge_threshold = 0.05
        return {'FINISHED'}    

# -----------------------------------------------------------------------------
#    Threshold
# ----------------------------------------------------------------------------- 


#Double Threshold 0.1
class Double_Threshold_Plus(bpy.types.Operator):
    bl_idname = "object.double_threshold_plus"
    bl_label = "Double Threshold 01"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        tool_settings = context.tool_settings
        bpy.context.scene.tool_settings.double_threshold = 0.1
        return {'FINISHED'}  
    
#Double Threshold 0.001
class Double_Threshold_Minus(bpy.types.Operator):
    bl_idname = "object.double_threshold_minus"
    bl_label = "Double Threshold 0001"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        tool_settings = context.tool_settings
        bpy.context.scene.tool_settings.double_threshold = 0.001
        return {'FINISHED'}

#Exit Retopo
class Exit_Retopo(bpy.types.Operator):
    bl_idname = 'object.exit_retopo'
    bl_label = ""

    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if len([obj for obj in context.selected_objects if context.object is not None if obj.type == 'MESH' if
                bpy.context.object.mode == "OBJECT"]) == 1:
            return True

    def execute(self, context):
        bpy.context.object.show_x_ray = False
        bpy.context.space_data.show_occlude_wire = False

        if "Retopo_Grid" in bpy.data.objects:
            bpy.ops.object.remove_retopo_grid()

        return {'FINISHED'}

# -----------------------------------------------------------------------------
#    UI
# -----------------------------------------------------------------------------        

#Update Panels
def speedretopo_update_panel_position(self, context):
    try:
        bpy.utils.unregister_class(SpeedRetopoTools)
        bpy.utils.unregister_class(SpeedRetopoUI)
    except:
        pass
    
    try:
        bpy.utils.unregister_class(SpeedRetopoUI)
    except:
        pass
    
    if context.user_preferences.addons[__name__].preferences.speedretopo_tab_location == 'tools':
        SpeedRetopoTools.bl_category = context.user_preferences.addons[__name__].preferences.category
        bpy.utils.register_class(SpeedRetopoTools)
    
    else:
        bpy.utils.register_class(SpeedRetopoUI)

#Tools    
class SpeedRetopoTools(bpy.types.Panel):
    bl_idname = "speed_retopo"
    bl_label = "SpeedRetopo"
    bl_space_type = "VIEW_3D"
    bl_region_type = "TOOLS"
    bl_category = "category"
    
    def draw(self, context):
        layout = self.layout
        WM = context.window_manager
        SpeedRetopo(self, context)

# UI                 
class SpeedRetopoUI(bpy.types.Panel):
    bl_label = "SpeedRetopo"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    
    def draw(self, context):
        layout = self.layout
        WM = context.window_manager
        SpeedRetopo(self, context)


#Panel
def SpeedRetopo(self, context):
    layout = self.layout
    WM = context.window_manager
    obj = context.active_object
    view = context.space_data
    tool_settings = context.tool_settings
    
    if context.object is not None :
        split = layout.split()
        col = split.column(align=True)
        row = col.row(align=True)
        row.label("Reference Object:")
        row = col.row(align=True)
        row.prop_search(WM, "ref_obj", bpy.data, 'objects', text='', icon='MESH_MONKEY')
        if context.object is not None and bpy.context.object.mode == "EDIT":  
            row.scale_x = 1.2
            row.prop(obj, "show_x_ray", text="", icon='UV_FACESEL')
            row.scale_x = 1.2
            row.prop(view, "show_occlude_wire",text="", icon='LATTICE_DATA')
    
    #Object
    if context.object is not None and bpy.context.object.mode == "OBJECT": 
        row = col.row(align=True)
        row.scale_y = 1.5   
        row.operator("object.create_speed_retopo", text="Setup Retopo", icon='MOD_TRIANGULATE')
        if any ([bpy.context.object.show_x_ray, bpy.context.space_data.show_occlude_wire, "Retopo_Grid" in bpy.data.objects]) == True:
            row = col.row(align=True)
            row.scale_y = 1.5
            row.operator("object.exit_retopo", text="Exit Retopo", icon='FILE_TICK')



    if context.object is not None and bpy.context.object.mode == "EDIT":  
    
        #Bsurface
        if hasattr(bpy.types, "GPENCIL_OT_surfsk_add_surface"):       
            row= layout.row(align=True)
            row.scale_y = 1.5
            row.scale_x = 1
            row.operator("gpencil.surfsk_add_surface", text="Add BSurface", icon='MOD_DYNAMICPAINT') 
            row.scale_x = 1.5
            row.operator("wm.context_toggle", text="", icon="ORTHO").data_path = "space_data.use_occlude_geometry"
            row.operator("object.align2x", text="", icon='MOD_WIREFRAME') 
            if hasattr(bpy.types, "MESH_OT_retopomt"):
                row = layout.row(align=True)
                row.scale_y = 1.5 
                row.operator("mesh.retopomt", icon='VPAINT_HLT')
            
        else :
            row= layout.row(align=True)
            row.scale_y = 1.5
            row.operator("object.activate_bsurfaces", text="Activate Bsurfaces", icon='ERROR') 
        
        #Shrinkwrap
        split = layout.split()
        col = split.column(align=True)
        shrinkwrap = bpy.context.active_object.modifiers.get("Shrinkwrap")
        if shrinkwrap :
            row=col.row(align=True)
            row.scale_x = 1
            row.scale_y = 1.5
            row.prop(bpy.context.active_object.modifiers["Shrinkwrap"], "offset", text = "Offset")
            row.scale_x = 1.2
            row.scale_y = 1.5
            row.operator("object.update_shrinwrap", text="", icon = 'LOOP_FORWARDS') 
            row.scale_x = 1.2
            row.scale_y = 1.5
            row.operator("apply.shrinkwrap", text="", icon = 'X') 
            
        else: 
            row=col.row(align=True) 
            row.scale_y = 1.3
            row.operator("object.add_shrinkwrap", text="Add shrinkwrap", icon = 'MOD_SHRINKWRAP')  
        
        #Mirror
        mirror = bpy.context.active_object.modifiers.get("Mirror")
        if mirror :
            split = layout.split()
            col = split.column(align=True)
            row = col.row(align=True)
            row.scale_y = 1.5
            row.scale_x = 1.2
            if bpy.context.object.modifiers["Mirror"].show_viewport == False :
                row.prop(bpy.context.active_object.modifiers["Mirror"], "show_viewport", text="Show Mirror", icon='RESTRICT_VIEW_ON') 
            elif bpy.context.object.modifiers["Mirror"].show_viewport == True :  
                row.prop(bpy.context.active_object.modifiers["Mirror"], "show_viewport", text="Hide Mirror", icon='RESTRICT_VIEW_OFF') 
#            row.prop(bpy.context.active_object.modifiers["Mirror"], "show_viewport", text="Hide Mirror") 
            row.prop(bpy.context.active_object.modifiers["Mirror"], "use_clip", text="", icon='UV_EDGESEL') 
            row.operator("apply.mirror", text="", icon='FILE_TICK') 
            row.operator("object.remove_mirror", text="", icon='X') 
            row = col.row(align=True)
            row.prop(bpy.context.active_object.modifiers["Mirror"], "merge_threshold", text="Merge Limit")    
            
        else:
            row = layout.row(align=True)
            row.scale_y = 1.5
            row.operator("object.mesh_automirror", text="Add Mirror", icon = 'MOD_MIRROR')

                             
        
        #activate Looptools                     
        if hasattr(bpy.types, "MESH_OT_looptools_bridge"):
            
            split = layout.split()
            col = split.column(align=True)
            row = col.row(align=True)
            row.scale_y = 1.5 
            row.operator("mesh.looptools_gstretch", text="GStretch", icon = 'LINE_DATA') 
            row.operator("object.space_relax", text="Space", icon = 'ALIGN')
            row = col.row(align=True)
            row.scale_y = 1.5 
            row.operator("mesh.looptools_bridge", text="Bridge", icon = 'MOD_LATTICE') 
            row.operator("mesh.fill_grid", text="Grid Fill", icon = 'OUTLINER_DATA_LATTICE')
        else:
            split = layout.split()
            col = split.column(align=True)
            row = col.row(align=True)
            row.scale_y = 1.5
            row.operator("object.activate_looptools", text="Activate Looptools", icon='ERROR')
            
        row = col.row(align=True)
        row.scale_y = 1.5 
        row.operator("mesh.speed_retopo_relax", text="Relax", icon = 'OUTLINER_OB_LATTICE')          
        
        #Grid    
        if not "Retopo_Grid" in bpy.data.objects :
            split = layout.split()
            col = split.column(align=True)            
            row=col.row(align=True) 
            row.scale_y = 1.3
            row.operator("object.recreate_grid", text="Add Retopo Grid", icon = 'OUTLINER_OB_LATTICE') 
            
        elif not "Shrinkwrap_Grid" in obj.modifiers : 
            split = layout.split()  
            col = split.column(align=True)        
            row=col.row(align=True) 
            row.scale_y = 1.3
            row.operator("object.recreate_grid", text="Connect Grid", icon = 'OUTLINER_OB_LATTICE')   
        else :  
            split = layout.split()  
            col = split.column(align=True)   
            row=col.row(align=True) 
            row.scale_y = 1.3
            if bpy.data.objects["Retopo_Grid"].hide == True:

                row.operator("object.hide_retopo_grid", text = "Show Grid", icon='RESTRICT_VIEW_ON')
            
            elif bpy.data.objects["Retopo_Grid"].hide == False:
                row.operator("object.hide_retopo_grid", text = "Hide Grid", icon='RESTRICT_VIEW_OFF')  
           
            row.scale_x = 1.2
            row.prop(bpy.data.objects['Retopo_Grid'], "show_wire", text = "", icon='MESH_GRID')
            row.scale_x = 1.2
            row.operator("object.scale_grid", text="", icon='MAN_SCALE') 
            row.scale_x = 1.2
            row.operator("object.remove_retopo_grid", text="", icon='X')
            
            row = col.row(align=True)
            row.prop(bpy.data.objects['Retopo_Grid'].modifiers['Subsurf'], "levels", text="Grid Divisions") 
            row = col.row(align=True)
            row.prop(bpy.data.materials['Retopo_Grid'], "diffuse_color", text = "")
            row.prop(bpy.data.materials['Retopo_Grid'], "alpha", text = "Alpha")
            
        #Threshold
        split = layout.split()
        col = split.column(align=True)
        row = col.row(align=True)
        row.scale_y = 1.3 
        if bpy.context.scene.tool_settings.use_mesh_automerge == False :
            row.prop(context.tool_settings, "use_mesh_automerge", text = "Auto Merge", icon='RADIOBUT_OFF')
        elif bpy.context.scene.tool_settings.use_mesh_automerge == True : 
            row.prop(context.tool_settings, "use_mesh_automerge", text = "Auto Merge", icon='RADIOBUT_ON')
            
        row = col.row(align=True)
        row.scale_y = 1.3 
        row.operator("object.double_threshold_minus", text= "0.001")  
        row.operator("object.double_threshold_plus", text= "0.1")
        row = col.row(align=True)  
        row.prop(tool_settings, "double_threshold", text="Threshold")
        
        
class Grid_Options_Menu(bpy.types.Operator):
    bl_idname = "view3d.grid_options_menu"
    bl_label = "Grid Settings"
 
    def execute(self, context):
        return {'FINISHED'}
    
    def check(self, context):
        return True
    
    def invoke(self, context, event):
#        AM = context.window_manager.asset_m
        self.dpi_value = bpy.context.user_preferences.system.dpi
 
        return context.window_manager.invoke_props_dialog(self, width=self.dpi_value*2.2, height=100)    

    def draw(self, context):
        layout = self.layout
        
        split = layout.split()
        col = split.column(align=True) 
        row = col.row(align=True)
        row.prop(bpy.data.objects['Retopo_Grid'].modifiers['Subsurf'], "levels", text="Grid Divisions") 
        row = col.row(align=True)
        row.prop(bpy.data.materials['Retopo_Grid'], "diffuse_color", text = "")
        row = col.row(align=True)
        row.prop(bpy.data.materials['Retopo_Grid'], "alpha", text = "Alpha")
         
                      
# Pie Menu                
class SpeedRetopoPieMenu(bpy.types.Menu):
    bl_idname = "view3d.speed_retopo_pie_menu"
    bl_label = "SpeedRetopo Pie Menu"
    
    
    def draw(self, context):
        pie = self.layout.menu_pie()
        WM = context.window_manager
        obj = context.active_object
        view = context.space_data
        tool_settings = context.tool_settings
        
#-------OBJECT_MODE
        if context.object is not None and bpy.context.object.mode == "OBJECT": 
            
            #4 - LEFT
            pie.separator()
            
            #6 - RIGHT
            pie.separator()
            
            #2 - BOTTOM
            pie.separator()
            
            #8 - TOP
            pie.operator("object.create_speed_retopo", text="Setup Retopo", icon='MOD_TRIANGULATE')
               
            #7 - TOP - LEFT 
            col = pie.column(align=True)
            row=col.row(align=True)
            row.label("Ref Object")
            row=col.row(align=True)
            row.scale_y = 1.5
            row.prop_search(WM, "ref_obj", bpy.data, 'objects', text='', icon='MESH_MONKEY')
                 
            #9 - TOP - RIGHT
            if any([bpy.context.object.show_x_ray, bpy.context.space_data.show_occlude_wire,
                    "Retopo_Grid" in bpy.data.objects]) == True:
                pie.operator("object.exit_retopo", text="Exit Retopo", icon='FILE_TICK')
            # pie.separator()
            
            #1 - BOTTOM - LEFT
            pie.separator()
            
            #3 - BOTTOM - RIGHT
            pie.separator()
        
        
#-------EDIT_MODE
        if context.object is not None and bpy.context.object.mode == "EDIT":  
            #4 - LEFT
            #------Mirror
            mirror = bpy.context.active_object.modifiers.get("Mirror")
            if mirror :
                col = pie.column(align=True)
                row=col.row(align=True)
                row.scale_y = 1.3
                row.scale_x = 0.8 
                if bpy.context.object.modifiers["Mirror"].show_viewport == False :
                    row.prop(bpy.context.active_object.modifiers["Mirror"], "show_viewport", text="Show Mirror", icon='RESTRICT_VIEW_ON') 
                elif bpy.context.object.modifiers["Mirror"].show_viewport == True :  
                    row.prop(bpy.context.active_object.modifiers["Mirror"], "show_viewport", text="Hide Mirror", icon='RESTRICT_VIEW_OFF') 
                row.scale_y = 1.3
                row.scale_x = 1.2
                row.prop(bpy.context.active_object.modifiers["Mirror"], "use_clip", text="", icon='UV_EDGESEL') 
                row.scale_y = 1.3
                row.scale_x = 1.2
                row.operator("apply.mirror", text="", icon = 'FILE_TICK')
                row.operator("object.remove_mirror", text="", icon = 'X')
                row = col.row(align=True)
                row.prop(bpy.context.active_object.modifiers["Mirror"], "merge_threshold", text="Merge Limit")  
            else:
                col = pie.column(align=True)
                row=col.row(align=True)
                row.scale_y = 1.3
                row.operator("object.mesh_automirror", text="Add Mirror", icon = 'MOD_MIRROR')
            
            #------shrinkwrap
            shrinkwrap = bpy.context.active_object.modifiers.get("Shrinkwrap")
            if shrinkwrap :
                row=col.row(align=True)
                row.scale_y = 1.3
                row.prop(bpy.context.active_object.modifiers["Shrinkwrap"], "offset", text="Offset")
                row.scale_x = 1.2
                row.scale_y = 1.3
                row.operator("object.update_shrinwrap", text="", icon = 'LOOP_FORWARDS') 
                row.scale_x = 1.2
                row.scale_y = 1.3
                row.operator("apply.shrinkwrap", text="", icon = 'X') 
                
            else: 
                row=col.row(align=True) 
                row.scale_y = 1.3
                row.operator("object.add_shrinkwrap", text="Add shrinkwrap", icon = 'MOD_SHRINKWRAP')   
            
            
            #6 - RIGHT
            pie.operator("object.align2x", text="Align to X", icon='MOD_WIREFRAME') 
            
                    
            #2 - BOTTOM
            if hasattr(bpy.types, "MESH_OT_retopomt"):
                pie.operator("mesh.retopomt", icon='VPAINT_HLT')
            
            else:
                if hasattr(bpy.types, "MESH_OT_looptools_bridge"):
                    pie.operator("mesh.fill_grid", text="Grid Fill", icon = 'OUTLINER_DATA_LATTICE')
                else:
                    row= pie.row()
                    row.scale_y = 1.5 
                    row.operator("object.activate_looptools", text="Activate Looptools", icon='ERROR')
                
            #8 - TOP
            if hasattr(bpy.types, "GPENCIL_OT_surfsk_add_surface"):
                pie.operator("gpencil.surfsk_add_surface", text="Add BSurface", icon='MOD_DYNAMICPAINT') 
            else :
                row.scale_y = 1.5 
                row.operator("object.activate_bsurfaces", text="Activate Bsurface", icon='ERROR') 
            
            #7 - TOP - LEFT 
            col = pie.column(align=True)
            row=col.row(align=True)
            row.prop_search(WM, "ref_obj", bpy.data, 'objects', text='', icon='MESH_MONKEY')
            row.scale_x = 1.2
            row.prop(obj, "show_x_ray", text="", icon='UV_FACESEL')
            row.scale_x = 1.2
            row.prop(view, "show_occlude_wire",text="", icon='LATTICE_DATA')
            
            #------Threshold
            row=col.row(align=True)
            row.scale_y = 1.3
            if bpy.context.scene.tool_settings.use_mesh_automerge == False :
                row.prop(context.tool_settings, "use_mesh_automerge", text = "Auto Merge", icon='RADIOBUT_OFF')
            elif bpy.context.scene.tool_settings.use_mesh_automerge == True : 
                row.prop(context.tool_settings, "use_mesh_automerge", text = "Auto Merge", icon='RADIOBUT_ON')
           
            
            row.operator("object.double_threshold_plus", text="0.1")
            row.operator("object.double_threshold_minus", text="0.001")  
                  
            #------Grid
            if not "Retopo_Grid" in bpy.data.objects :
                row=col.row(align=True) 
                row.scale_y = 1.3
                row.operator("object.recreate_grid", text="Add Retopo Grid", icon = 'OUTLINER_OB_LATTICE') 
                
            elif not "Shrinkwrap_Grid" in obj.modifiers :   
                row=col.row(align=True) 
                row.scale_y = 1.3
                row.operator("object.recreate_grid", text="Connect Grid", icon = 'OUTLINER_OB_LATTICE')   
            else :    
                row=col.row(align=True) 
                row.scale_y = 1.3
                if bpy.data.objects["Retopo_Grid"].hide == True:

                    row.operator("object.hide_retopo_grid", text = "Show Grid", icon='RESTRICT_VIEW_ON')
                
                elif bpy.data.objects["Retopo_Grid"].hide == False:
                    row.operator("object.hide_retopo_grid", text = "Hide Grid", icon='RESTRICT_VIEW_OFF')  
               
                row.scale_x = 1.2
                row.prop(bpy.data.objects['Retopo_Grid'], "show_wire", text = "", icon='MESH_GRID')
                row.scale_x = 1.2
                row.operator("object.scale_grid", text="", icon='MAN_SCALE') 
                row.scale_x = 1.2
                row.operator("view3d.grid_options_menu", icon='SCRIPTWIN', text='')
                row.scale_x = 1.2
                row.operator("object.remove_retopo_grid", text="", icon='X')
                
            #9 - TOP - RIGHT
            if hasattr(bpy.types, "MESH_OT_looptools_bridge"):
                pie.operator("object.space_relax", text="Space", icon = 'ALIGN')
            else:
                row= pie.row()
                row.scale_y = 1.5 
                row.operator("object.activate_looptools", text="Activate Looptools", icon='ERROR')
            
            #1 - BOTTOM - LEFT
            if hasattr(bpy.types, "MESH_OT_looptools_bridge"):
                split = pie.split()
                col = split.column(align=True)
                if hasattr(bpy.types, "MESH_OT_retopomt"):
                    row = col.row(align=True)
                    row.scale_y = 1.3
                    row.scale_x = 1.5 
                    row.operator("mesh.fill_grid", text="Grid Fill", icon = 'OUTLINER_DATA_LATTICE')
                
                row = col.row(align=True)
                row.scale_y = 1.3
                row.scale_x = 1.5 
                row.operator("mesh.looptools_gstretch", text="GStretch", icon = 'LINE_DATA')
                row = col.row(align=True)
                row.scale_y = 1.3
                row.scale_x = 1.5
                row.operator("mesh.looptools_bridge", text="Bridge", icon = 'MOD_LATTICE') 
            else:
                row= pie.row()
                row.scale_y = 1.5 
                row.operator("object.activate_looptools", text="Activate Looptools", icon='ERROR') 
            
            #3 - BOTTOM - RIGHT
            pie.operator("mesh.speed_retopo_relax", text="Relax", icon = 'OUTLINER_OB_LATTICE') 



# -----------------------------------------------------------------------------
#    Preferences      
# ----------------------------------------------------------------------------- 

# Preferences            
class AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__
    
            
    prefs_tabs = EnumProperty(
        items=(('options', "Options", "Options"),
               ('links', "Links", "Links")),
               default='options'
               )
                      
    category = bpy.props.StringProperty(
            name="Category",
            description="Choose a name for the category of the panel",
            default="Tools",
            update=speedretopo_update_panel_position) 
    
    use_pie_menu = BoolProperty(
            name="Use Pie Menu", 
            default=True
            )
    
    #Grid Options
    use_grid = BoolProperty(
            name="Use Grid", 
            default=True
            )
    
    grid_color = FloatVectorProperty(
            name="Color:", 
            default=(0.1, 0.3, 0.5), 
            min=0, max=1,
            precision=3, 
            subtype='COLOR'
            )  
    
    grid_alpha = FloatProperty(
            default=0.5,
            min=0, max=1,
            precision=3
            )
    
    grid_show_wire = BoolProperty(
            name="Show wire", 
            default=True
            )    
            
    grid_subdivisions = IntProperty(
            name="",
            default=3,
            min=0, max=6
            )   

                                         
    #Tab Location           
    speedretopo_tab_location = EnumProperty(
        name = 'Panel Location',
        description = 'The 3D view shelf to use. (Save user settings and restart Blender)',
        items=(('tools', 'Tool Shelf', 'Places the Asset Management panel in the tool shelf'),
               ('ui', 'Property Shelf', 'Places the Asset Management panel in the property shelf.')),
               default='tools',
               update = speedretopo_update_panel_position,
               )
                                    
    def draw(self, context):
            layout = self.layout
            wm = bpy.context.window_manager
            
            
            row= layout.row(align=True)
            row.prop(self, "prefs_tabs", expand=True)
            if self.prefs_tabs == 'options':
                layout = self.layout
                
                box = layout.box()
                box.label("Panel Location: ")
                
                row= box.row(align=True)
                row.prop(self, 'speedretopo_tab_location', expand=True)
                row = box.row()
                if self.speedretopo_tab_location == 'tools':
                    split = box.split()
                    col = split.column()
                    col.label(text="Change Category:")
                    col = split.column(align=True)
                    col.prop(self, "category", text="") 
                
                row= box.row(align=True)
                row.prop(self, 'use_pie_menu', expand=True)
                
                #Keymap pie menu
                if self.use_pie_menu :
                    split = box.split()
                    col = split.column()       
                    col.label('Setup Pie menu Hotkey')
                    col.separator()
                    wm = bpy.context.window_manager
                    kc = wm.keyconfigs.user
                    km = kc.keymaps['3D View Generic']
                    kmi = get_hotkey_entry_item(km, 'wm.call_menu_pie', 'view3d.speed_retopo_pie_menu')
                    if kmi:
                        col.context_pointer_set("keymap", km)
                        rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
                    else:
                        col.label("No hotkey entry found")
                        col.operator(SpeedRetopoAddHotkey.bl_idname, text = "Add hotkey entry", icon = 'ZOOMIN')
                
                
                row = box.row(align=True)
                row.label("Save preferences to apply these settings", icon='ERROR')
                
                box = layout.box()
                box.label("Grid Options: ")
                split = box.split()
                
                row = box.row(align=True)       
                row.prop(self, "use_grid", expand=True)
                
                row = box.row(align=True)
                row.label("Grid Color:")          
                row.prop(self, "grid_color", text="")
                
                row = box.row(align=True)
                row.label("Grid Alpha:")          
                row.prop(self, "grid_alpha", text="")
                
                row = box.row(align=True)
                row.label("Grid Subdivisions:")          
                row.prop(self, "grid_subdivisions", text="")
                
                row = box.row(align=True)       
                row.prop(self, "grid_show_wire", expand=True)
                
                    
                layout.label("Informations :")   
                layout.label("Welcome to SpeedRetopo, this addon allows you to create fast retopologies")   
                layout.label("To use is, activate Bsurface, Looptools and Automirror") 
                
            if self.prefs_tabs == 'links':  
                layout.operator("wm.url_open", text="Asset Management").url = "https://gumroad.com/l/kANV"
                layout.operator("wm.url_open", text="Speedflow").url = "https://gumroad.com/l/speedflow"
                layout.operator("wm.url_open", text="SpeedSculpt").url = "https://gumroad.com/l/SpeedSculpt"
                layout.separator() 
                layout.operator("wm.url_open", text="Pitiwazou.com").url = "http://www.pitiwazou.com/"
                layout.operator("wm.url_open", text="Wazou's Ghitub").url = "https://github.com/pitiwazou/Scripts-Blender"
                layout.operator("wm.url_open", text="BlenderLounge Forum").url = "http://blenderlounge.fr/forum/"  
                            

addon_keymaps = [] 
         

def get_hotkey_entry_item(km, kmi_name, kmi_value):
    '''
    returns hotkey of specific type, with specific properties.name (keymap is not a dict, so referencing by keys is not enough
    if there are multiple hotkeys!)
    '''
    for i, km_item in enumerate(km.keymap_items):
        if km.keymap_items.keys()[i] == kmi_name:
            if km.keymap_items[i].properties.name == kmi_value:
                return km_item
    return None 


def add_hotkey():
    user_preferences = bpy.context.user_preferences
    addon_prefs = user_preferences.addons[__name__].preferences
    
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon 
    km = kc.keymaps.new(name="3D View Generic", space_type='VIEW_3D', region_type='WINDOW')  
    kmi = km.keymap_items.new("wm.call_menu_pie",'RIGHTMOUSE', 'PRESS', shift=True)     
    kmi.properties.name = "view3d.speed_retopo_pie_menu"                           
    kmi.active = True
    addon_keymaps.append((km, kmi))


class SpeedRetopoAddHotkey(bpy.types.Operator):
    ''' Add hotkey entry '''
    bl_idname = "speedretopo.add_hotkey"
    bl_label = "Addon Preferences Example"
    bl_options = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        add_hotkey()

        self.report({'INFO'}, "Hotkey added in User Preferences -> Input -> Screen -> Screen (Global)")
        return {'FINISHED'}
    
    
def remove_hotkey():
    ''' clears all addon level keymap hotkeys stored in addon_keymaps '''
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    km = kc.keymaps['3D View Generic']
    
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
        wm.keyconfigs.addon.keymaps.remove(km)
    addon_keymaps.clear()
#Add Hotkeys
#def speedretopo_add_hotkey():
#    user_preferences = bpy.context.user_preferences
#    addon_prefs = user_preferences.addons[__name__].preferences
#    
#    #Pie menu
#    if bpy.context.user_preferences.addons[__name__].preferences.use_pie_menu :
#        kc = bpy.context.window_manager.keyconfigs.user
#        km = kc.keymaps['3D View Generic']
#        kmi = km.keymap_items.new("wm.call_menu_pie", 'RIGHTMOUSE', 'PRESS', shift=True)
#        kmi.properties.name = "view3d.speed_retopo_pie_menu"
#        kmi.active = True


#addon_keymaps = []


#def get_hotkey_entry_item(km, kmi_name, kmi_value):
#    '''
#    returns hotkey of specific type, with specific properties.name (keymap is not a dict, so referencing by keys is not enough
#    if there are multiple hotkeys!)
#    '''
#    for i, km_item in enumerate(km.keymap_items):
#        if km.keymap_items.keys()[i] == kmi_name:
#            if km.keymap_items[i].properties.name == kmi_value:
#                return km_item
#    return None

#def speedretopo_add_hotkey():
#    user_preferences = bpy.context.user_preferences
#    addon_prefs = user_preferences.addons[__name__].preferences
#    
#    wm = bpy.context.window_manager
#    kc = wm.keyconfigs.addon
#    km = kc.keymaps.new(name="3D View Generic", space_type='VIEW_3D', region_type='WINDOW')
#    kmi = km.keymap_items.new("wm.call_menu_pie",'RIGHTMOUSE', 'PRESS', shift=True)
#    kmi.properties.name = "view3d.speed_retopo_pie_menu"
#    kmi.active = True
#    addon_keymaps.append((km, kmi))


#class SpeedRetopo_AddHotkey(bpy.types.Operator):
#    bl_idname = "speedretopo.add_hotkey"
#    bl_label = "Addon Preferences Example"
#    bl_options = {'REGISTER', 'INTERNAL'}

#    def execute(self, context):
#        speedretopo_add_hotkey()

#        self.report({'INFO'}, "Hotkey added in User Preferences -> Input -> Screen -> Screen (Global)")
#        return {'FINISHED'}    
#    
#def remove_hotkey():
#    ''' clears all addon level keymap hotkeys stored in addon_keymaps '''
#    wm = bpy.context.window_manager
#    kc = wm.keyconfigs.addon
#    km = kc.keymaps['3D View Generic']
#    
#    for km, kmi in addon_keymaps:
#        km.keymap_items.remove(kmi)
#        wm.keyconfigs.addon.keymaps.remove(km)
#    addon_keymaps.clear()
    
          
def register():
    bpy.utils.register_module(__name__)
    
    #register macro
    Test.define("TRANSFORM_OT_resize")
    Test.define("TEST_OT_finalize")
    
    #panel position
    speedretopo_update_panel_position(None, bpy.context)

    # hotkey setup
    add_hotkey()
    
def unregister():
    bpy.utils.unregister_module(__name__)
    
    # hotkey cleanup
    remove_hotkey()
    

if __name__ == "__main__":
    register()
            